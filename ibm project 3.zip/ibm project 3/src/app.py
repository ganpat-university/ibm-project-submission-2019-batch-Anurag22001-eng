import streamlit as st
import requests
import pandas as pd

st.title('Top 10 Candidates for job')

job_position = st.selectbox(
    'Which Job would you like to see the best candidates for?',
    ['Software Developer', 'Backend Developer', 'Backend NodeJS Developer','Cloud DevOps Specialist','Game Developer','Mobile Developer (React Native)','Senior Front End Engineer','Senior Mobile App Developer','Sr Backend Developer (Python)','Sr Backend Engineer (Java)'])

# Make a GET request to the Flask app endpoint
response = requests.get(f'http://localhost:5000/api/candidates?job_position={job_position}')

# Extract data from response
result_df = pd.read_json(response.json())

st.write(result_df)
