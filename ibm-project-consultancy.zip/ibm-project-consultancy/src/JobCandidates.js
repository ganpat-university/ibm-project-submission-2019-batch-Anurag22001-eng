import React, { useState, useEffect } from 'react';

function JobCandidates() {
  const [candidates, setCandidates] = useState([]);

  useEffect(() => {
    async function fetchData() {
      const response = await fetch('/job_candidates?job_position=Software Engineer');
      const data = await response.json();
      setCandidates(data);
    }
    fetchData();
  }, []);

  return (
    <div>
      <h1>Top 10 Candidates for Software Engineer job</h1>
      <ul>
        {candidates.map(candidate => (
          <li key={candidate.id}>
            {candidate.name} - {candidate.match_score}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default JobCandidates;
