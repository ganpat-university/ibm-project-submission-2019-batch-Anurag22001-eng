import React, { useState, useEffect } from "react";
import axios from 'axios'
function App() {
  const [jobPosition, setJobPosition] = useState("Software Developer");
  const [candidates, setCandidates] = useState([]);

  useEffect(() => {
    setCandidates([])
    axios.get(`http://localhost:5000/api/candidates?job_position=${jobPosition}`)
      .then((response) => setCandidates(response.data))
      
  }, [jobPosition]);
useEffect(()=>{
  console.log(candidates)
},[candidates])
  const handleJobPositionChange = (event) => {
    setJobPosition(event.target.value);
  };

  return (
    <div>
      <h1>Top 10 Candidates for Job</h1>
      <label>
        Select a job position:
        <select value={jobPosition} onChange={handleJobPositionChange}>
          <option value="Software Developer">Software Developer</option>
          <option value="Backend Developer">Backend Developer</option>
          <option value="Backend NodeJS Developer">Backend NodeJS Developer</option>
          <option value="Cloud DevOps Specialist">Cloud DevOps Specialist</option>
          <option value="Game Developer">Game Developert</option>
          <option value="Mobile Developer (React Native)">Mobile Developer (React Native)</option>
          <option value="Senior Front End Engineer">Senior Front End Engineer</option>
          <option value="Senior Mobile App Developer">Senior Mobile App Developer</option>
          <option value="Sr Backend Developer (Python)">Sr Backend Developer (Python)</option>
          <option value="Sr Backend Engineer (Java)">Sr Backend Engineer (Java)</option>
        </select>
      </label>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Experience</th>
            <th>Education</th>
            <th>Match Score</th>
          </tr>
        </thead>
        <tbody>
          {candidates&&candidates.map((candidate) => (
            <tr key={candidate.jobid}>
              <td>{candidate.userid}</td>
              <td>{candidate.jobskills}</td>
              <td>{candidate.jobsposition}</td>
              <td>{candidate.userskills}</td>
              <td>{candidate.match_score}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default App;
